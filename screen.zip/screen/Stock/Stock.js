import { StyleSheet, Text, View } from 'react-native';
import ButtonHome from '../../components/ButtonHome.js';
import Icon_menu from '../../components/Menu_bar.js';
import Backg from '../../components/back.js';
import React from 'react';
import { useNavigation } from '@react-navigation/core';


const Stock = () => {

  return (
    <View>
      <View style={[styles.container]}> 

        <View style={styles.back}>
          <Backg/>
          <Text style={styles.name}>{'Le train bleu'}</Text>
        </View>
        
        <View style={styles.button}>
          <ButtonHome text='Stock' onPress={Stockpress}/>
          <ButtonHome text='Commande' onPress={Commandepress}/>
          <ButtonHome text='Historique' onPress={Historiquepress}/>
          <ButtonHome text='Statistique' onPress={Statistiquepress}/>
        </View>

        <View style={styles.menu}>
          <View style={{ flexDirection: 'row' }}>
            <Icon_menu text='Humburger'/>
            <Icon_menu text='Home'/>
            <Icon_menu text='Scan'/>
            <Icon_menu text='bell'/>
          </View>
        </View>

      </View>
    </View>

  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor : '#F5F5F5',
  },

  name:{
    position: 'absolute',
    width: 239,
    height: 53,
    left: 44,
    top: 100,
    fontWeight: 500,
    fontSize: 40,
    Lineheight: 53,
    color: '#FFFFFF',

  },

  button: {
    marginTop: 250,
    alignItems: 'center',
    justifyContent: 'center',
  },

  menu: {
    width: 391,
    height: 100,
    marginTop: 25,
    backgroundColor: '#2F3031',
    border: 1,
    borderBottomColor: 'black',
    borderRadius: 40,
    alignItems: 'center',
    paddingTop: 30,
  },
});