import { View, Image, Text, TouchableOpacity, StyleSheet } from 'react-native'
import React from 'react'

export default function Backg() {
//   const tailwind = useTailwind();
  return (
    <View style={[styles.back]}>
        <View style={styles.back1}></View>
        <View style={styles.back2}></View>
        <View style={styles.back3}></View>
        <View style={styles.back4}></View>
        <View style={styles.back5}></View>
    </View>
    )
}

const styles = StyleSheet.create({

    back1: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: 301,
        height: 195,
        backgroundColor: '#2F3031',
    },

    back2: {
        position: 'absolute',
        width: 195,
        height: 122,
        left: 198,
        top: 0,
        backgroundColor: '#2F3031',
    },

    back3: {
        position: 'absolute',
        width: 92.2,
        height: 150,
        left: 0,
        top: 130,
        backgroundColor: '#2F3031',
    },

    back4: {
        position: 'absolute',
        width: 189.42,
        height: 160,
        left: 203.45,
        top: 35,
        borderRadius:150 ,
        backgroundColor: '#2F3031',
    },

    back5: {
        position: 'absolute',
        width: 189.42,
        height: 160,
        left: 0,
        top: 195,
        borderRadius: 100,
        backgroundColor: '#F5F5F5',
    }
});