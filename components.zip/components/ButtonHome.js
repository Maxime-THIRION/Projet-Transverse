import { View, Image, Text, TouchableOpacity, StyleSheet } from 'react-native'
import React, { useState }from 'react'


// import {useTailwind} from 'tailwind-rn';


// interface ButtonHomeprops {
//   children: string,
//   onPress: (children: any) => void,
//   //chercher onpress avec children
//   //recherche ts et nn reacnative
// }

export default function ButtonHome({text, onPress}) {
  const [texte] = useState(text);
  return (
      <View>
        {texte === 'Stock' ? (
          <TouchableOpacity onPress={onPress}>
            <View style={{borderTopLeftRadius: 45, ...styles.button}}>
              <View style={{backgroundColor: 'rgba(151, 181, 235, 0.5)',borderTopLeftRadius: 25, opacity: 0.8, ...styles.cadre}}>
                <Image source={require('../../img/product.png')}
                style={{ width: 35, height: 35}}
                />
              </View>
              <Text style={styles.text}>{text}</Text>
              <Image source={require('../../img/fleche.png')}
                style={{width: 25, height: 25, position: 'absolute', right: 20}}/>
            </View>
          </TouchableOpacity>
          
        ) : texte === 'Commande' ?(
          <TouchableOpacity onPress={onPress}>
            <View style={styles.button}>
            <View style={{backgroundColor: 'rgba(137, 205, 136, 0.7)', ...styles.cadre}}>
                <Image source={require('../../img/list.png')}
                style={{ width: 30, height: 30}}
                />
              </View>
              <Text style={styles.text}>{text}</Text>
              <Image source={require('../../img/fleche.png')}
                style={{width: 25, height: 25, position: 'absolute', right: 20}}/>
            </View>
          </TouchableOpacity>

        ) : texte === 'Historique' ?(
          <TouchableOpacity onPress={onPress}>
            <View style={styles.button}>
            <View style={{backgroundColor: 'rgba(228, 191, 191, 0.5)', ...styles.cadre}}>
                <Image source={require('../../img/time-management.png')}
                style={{ width: 30, height: 30}}
                />
              </View>
              <Text style={styles.text}>{text}</Text>
              <Image source={require('../../img/fleche.png')}
                style={{width: 25, height: 25, position: 'absolute', right: 20}}/>
            </View>
          </TouchableOpacity>

        ) : texte === 'Statistique' ?(
          <TouchableOpacity onPress={onPress}>
            <View style={styles.button}>
            <View style={{backgroundColor: 'rgba(209, 193, 235, 0.7)', ...styles.cadre}}>
                <Image source={require('../../img/stats.png')}
                style={{ width: 30, height: 30}}
                />
              </View>
              <Text style={styles.text}>{text}</Text>
              <Image source={require('../../img/fleche.png')}
                style={{width: 25, height: 25, position: 'absolute', right: 20}}/>
            </View>
          </TouchableOpacity>

        ) : (
          <Text>Section introuvable</Text>
        )}
      </View>
  );
};

const styles = StyleSheet.create({
  button: {
    width: 330,
    height: 98.19,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    marginBottom: 20,
    alignContent: 'center',
    paddingLeft: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },

  cadre: {
    width: 60,
    height: 60,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },

  text: {
    marginLeft: 20,
    fontFamily: 'Akshar',
    fontSize: 24,
    fontWeight: 400,
    Lineheight: 26,
  },
});



